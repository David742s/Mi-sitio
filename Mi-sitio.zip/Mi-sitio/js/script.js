// Podés agregar funcionalidades futuras aquí
console.log("Sitio cargado correctamente");
